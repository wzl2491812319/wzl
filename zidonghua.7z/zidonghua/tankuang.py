from  selenium  import  webdriver
import  time

driver = webdriver.Chrome()

driver.get(r"D:\python自动化测试\自动化项目\day01\练习的html\弹框的验证\dialogs.html")

driver.maximize_window()

driver.find_element_by_id("confirm").click()

time.sleep(1)

# driver.switch_to.alert.accept() # 点击弹框里的确定

driver.switch_to.alert.dismiss() # 点击取消

time.sleep(3)

driver.quit()



