from selenium import webdriver
import time
#获取驱动
driver = webdriver.Chrome()
#打开浏览器
driver.get("https://www.baidu.com")
#窗口最大化
driver.maximize_window()
#定位搜索输入框
driver.find_element_by_id("kw").send_keys("python")
#定位百度一下按钮
driver.find_element_by_id("su").click()
#设置睡眠时间
time.sleep(3)
#关闭网页
driver.quit()