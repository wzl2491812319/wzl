'''
上传文件和下拉列表

'''
from  selenium  import  webdriver
import  time

driver = webdriver.Chrome()

driver.get(r"D:\python自动化测试\自动化项目\day01\练习的html\上传文件和下拉列表\autotest.html")

driver.maximize_window()

driver.find_element_by_xpath("//*[@id='accountID']").send_keys("jason")

driver.find_element_by_xpath("//*[@id='passwordID']").send_keys("admin")

driver.find_element_by_xpath("//*[@id='areaID']").send_keys("北京市")

driver.find_element_by_xpath("//*[@id='sexID2']").click()

driver.find_element_by_xpath("//*[@name='u3'][2]").click()
driver.find_element_by_xpath("//*[@name='u3'][3]").click()

driver.find_element_by_xpath("//*[@name='file']").send_keys("D:\\python自动化测试\\自动化项目\\day01\\1.jpeg")




time.sleep(1)


# driver.switch_to.alert.accept() # 点击弹框里的确定

# driver.switch_to.alert.dismiss() # 点击取消

time.sleep(3)

driver.quit()



