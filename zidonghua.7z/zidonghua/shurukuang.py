from selenium import webdriver
import time

driver = webdriver.Chrome()
driver.get(r"D:\python自动化测试\自动化项目\day01\练习的html\frame.html")

driver.maximize_window()
driver.find_element_by_id("input1").send_keys("java")
driver.find_element_by_xpath("//*[@id = 'input1']").send_keys("javaa")
driver.find_element_by_xpath("html/body/input[@id='input1']").send_keys("abc")

time.sleep(3)
driver.quit()






