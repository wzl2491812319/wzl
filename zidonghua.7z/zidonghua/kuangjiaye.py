import time
from selenium import webdriver


driver = webdriver.Chrome()

driver.get(r"D:\python自动化测试\自动化项目\day01\练习的html\main.html")

driver.maximize_window()

driver.switch_to.frame("frame")#进入框架页

driver.find_element_by_id("input1").send_keys("java")

driver.switch_to.default_content() # 跳出默认的框架页


time.sleep(3)
driver.quit()

