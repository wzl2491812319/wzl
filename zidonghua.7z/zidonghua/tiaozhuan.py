from selenium import webdriver
import time
drive = webdriver.Chrome()
drive.get("D:\python自动化测试\自动化项目\day01\练习的html\跳转页面\pop.html")

drive.maximize_window()
drive.find_element_by_xpath("//*[@id='goo']").click()
drive.switch_to.window(drive.window_handles[1])
drive.find_element_by_xpath("//*[@id='kw']").send_keys('java')
drive.find_element_by_xpath("//*[@id='kw']").click()
time.sleep(3)
drive.quit()